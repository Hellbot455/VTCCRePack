This is the resource pack used on BanchaVT's Community Server

It does not change any existing textures or sounds, only offering alternative models for named weapons.

To get your own named weapon, contact on Discord: Succulent_Goulash#4891

You get one free model. To get more than one, fund the server.
